

<?php $__env->startSection('content'); ?>
    <div class="container-fluid main-content py-4 d-flex flex-wrap ">
        <?php if(count($sections) == 0): ?>
            <div class="text-warning h5">You have no sections. Please create one using the Create Section button below or from <u><a href="/faculty/section/create">here.</a></u> </div>
        <?php endif; ?>
        <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card nightbg soft-shadow mx-3 my-3">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($section->sectionname); ?></h5>
                    
                    <?php $__currentLoopData = $section->sectiontimes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sectiontime): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <h6 class="card-text font-italic text-nowrap mb-2"><?php echo e('[' . $sectiontime->classtype . '] ' . $sectiontime->weekday . ' ' . $sectiontime->starttime . ' - ' . $sectiontime->endtime . ' at ' . $sectiontime->room); ?></h6>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if(count($section->sectiontimes) == 1): ?>
                        <h6 class="card-text font-italic text-nowrap"><br></h6>
                    <?php endif; ?>
                    <div class="d-flex flex-row justify-content-between align-items-center mt-3">
                        <a href="/faculty/section/<?php echo e($section->eid); ?>/students/" class="btn btn-seablue">Students</a>
                        <a href="/faculty/section/<?php echo e($section->eid); ?>/lectures/" class="btn btn-seablue">Lectures</a>
                        <a href="/faculty/section/<?php echo e($section->eid); ?>/edit/" class="btn btn-seablue">Edit</a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <a href="/faculty/section/create" class="">
            <button class="btn btn-seablue float soft-shadow px-3">
                <i class="fa fa-plus"></i>
                <p class="d-inline create">Create Section</p>
            </button>
        </a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.faculty_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\msi\repos\asw\resources\views/faculty/section/sections.blade.php ENDPATH**/ ?>