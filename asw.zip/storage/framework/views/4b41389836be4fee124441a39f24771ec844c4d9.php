<?php $__env->startSection('title', __('Teapot')); ?>
<?php $__env->startSection('code', '418'); ?>
<?php $__env->startSection('message', __('I\'m a teapot')); ?>
<?php $__env->startSection('extra'); ?>
    <iframe src="https://giphy.com/embed/l0EwYRXhyq1rpn4Gc" width="480" height="269" frameBorder="0" class="giphy-embed" allowFullScreen></iframe>
    <p><a href="https://giphy.com/gifs/tea-zoom-mug-l0EwYRXhyq1rpn4Gc"></a></p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('errors::illustrated-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\msi\repos\asw\resources\views/errors/418.blade.php ENDPATH**/ ?>