

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="main d-flex flex-row flex-wrap">
            <div class="login login-main d-inline vw-30">
                <h2 class="mb-4">Error 418</h2>
                <h4>I'm a teapot</h4>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\msi\repos\asw\resources\views/global/teapot.blade.php ENDPATH**/ ?>