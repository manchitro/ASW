<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="main d-flex flex-row flex-wrap">
            <div class="welcome-msg d-inline mb-2">
                <h1 class="welcome">Welcome to ASW</h1>
                <h4 class="automate">Automate Your Class with Attendance Scanning</h4>
                <div class="steps mw-50">
                    <p>Submit your attendance by scanning the QR code your teacher shows in class using our mobile app.</p>
                </div>
            </div>
            <?php if(!session()->has('user')): ?>
                <?php $__env->startComponent('components.loginform'); ?>
                <?php if (isset($__componentOriginal660e59c31d0047e44bf85e53084671539be235f5)): ?>
<?php $component = $__componentOriginal660e59c31d0047e44bf85e53084671539be235f5; ?>
<?php unset($__componentOriginal660e59c31d0047e44bf85e53084671539be235f5); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
            <?php else: ?>
                <a href="/user" class="btn btn-lg btn-outline-success">Go to your portal</a>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\msi\repos\asw\resources\views/global/home.blade.php ENDPATH**/ ?>