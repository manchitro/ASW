

<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('components.right-menu'); ?>
        <?php $__env->slot('sectioneid'); ?>
            <?php echo e($section->eid); ?>

        <?php $__env->endSlot(); ?>
        <?php $__env->slot('currentpage'); ?>
            <?php echo e('addstudent'); ?>

        <?php $__env->endSlot(); ?>
        <?php $__env->slot('rightmenustate'); ?>
            <?php echo e($user->rightmenustate); ?>

        <?php $__env->endSlot(); ?>
    <?php if (isset($__componentOriginal07040f813646d8732f1180ba4b40ef47cbdeac00)): ?>
<?php $component = $__componentOriginal07040f813646d8732f1180ba4b40ef47cbdeac00; ?>
<?php unset($__componentOriginal07040f813646d8732f1180ba4b40ef47cbdeac00); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <div class="container-fluid main-content py-4 d-flex flex-wrap ">
        <form action="" method="post" class="section-form w-75" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="border-left pl-3 mt-4 mb-4">
                <h3>Importing excel sheet</h3>
            </div>
            <div class="border-left pl-3 mt-4 mb-4">
                <p>The excel sheet you you'll provide must fulfill the following requirements:</p>
                <ol>
                    <li>
                        <p>Sheet should have at least 2 columns. A Student ID column and a Name column</p>
                    </li>
                    <li>
                        <p>Student ID should be the leftmost column and the name column should follow immediately</p>
                    </li>
                    <li>
                        <p>The first row will be treated as a header row and it will be assumed that header does not contain any student information. Therefore, information processing will start from the second row.</p>
                    </li>
                    <li>
                        <p>Any other column after these will be ignored.</p>
                    </li>
                    <li>
                        <p>The header of the column does no matter. The first column will always be treated as the Student ID column and the 2nd column will be treated as the Name column</p>
                    </li>
                </ol>
                <a href="<?php echo e(asset('files/exampleSheet.xlsx')); ?>" class="color-seablue">Download an example sheet</a>
            </div>
            <div class="border-left pl-3 mt-4 mb-4">
                <div class="input-group mb-3">
                    <input type="file" class="custom-file-input" id="sheet" name="sheet">
                    <label class="custom-file-label" for="customFile">Click to browse excel file</label>
                    <?php $__errorArgs = ['sheet'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="border-left pl-3 mt-4 mb-4">
                <button class="btn btn-seablue" type="submit">Upload</button>
            </div>
            <script>
                window.addEventListener('load', function() {
                    $(".custom-file-input").on("change", function() {
                        var fileName = $(this).val().split("\\").pop();
                        $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
                    });
                })

            </script>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.faculty_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\msi\repos\asw\resources\views/faculty/section/addstudentsheet.blade.php ENDPATH**/ ?>