

<?php $__env->startSection('content'); ?>
    <div class="container-fluid main-content py-4 d-flex flex-wrap ">
        <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card nightbg soft-shadow mx-5 my-3">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($section->sectionname); ?></h5>
                    
                    <?php $__currentLoopData = $section->sectiontimes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sectiontime): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <h6 class="card-text font-italic text-nowrap"><?php echo e($sectiontime->weekday . ' ' . $sectiontime->starttime . ' - ' . $sectiontime->endtime . ' at ' . $sectiontime->room); ?></h6>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if(count($section->sectiontimes) == 1): ?>
                        <h6 class="card-text font-italic text-nowrap"><br></h6>
                    <?php endif; ?>
                    <div class="d-flex flex-row justify-content-between align-items-center mt-3">
                        <a href="/faculty/section/<?php echo e($section->eid); ?>/students/" class=""><button class="btn btn-outline-seablue">Students</button></a>
                        <a href="/faculty/section/<?php echo e($section->eid); ?>/classes" class=""><button class="btn btn-outline-seablue">Classes</button></a>
                        <a href="/faculty/section/<?php echo e($section->eid); ?>/edit" class=""><button class="btn btn-outline-seablue">Edit</button></a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <button class="btn btn-seablue float soft-shadow px-3">
            <a href="/faculty/section/create" class="">
                <i class="fa fa-plus"></i>
                <p class="d-inline create">Create Section</p>
            </a>
        </button>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.faculty_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\msi\repos\asw\resources\views/faculty/sections.blade.php ENDPATH**/ ?>