

<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('components.right-menu'); ?>
        <?php $__env->slot('sectioneid'); ?>
            <?php echo e($section->eid); ?>

        <?php $__env->endSlot(); ?>
        <?php $__env->slot('currentpage'); ?>
            <?php echo e('addstudent'); ?>

        <?php $__env->endSlot(); ?>
        <?php $__env->slot('rightmenustate'); ?>
            <?php echo e($user->rightmenustate); ?>

        <?php $__env->endSlot(); ?>
    <?php if (isset($__componentOriginal07040f813646d8732f1180ba4b40ef47cbdeac00)): ?>
<?php $component = $__componentOriginal07040f813646d8732f1180ba4b40ef47cbdeac00; ?>
<?php unset($__componentOriginal07040f813646d8732f1180ba4b40ef47cbdeac00); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <div class="container-fluid main-content py-4 d-flex flex-wrap ">
        <form action="" method="post" class="section-form w-100">
            <div class="border-left pl-3 mt-4 mb-4">
                <h3>Import excel sheet</h3>
                <p>You can download an excel sheet that contains the ID and name of the students from your portal. Import that sheet here to automatically add all students in your section</p>
                <a href="add/sheet" class="btn btn-seablue">Import Excel</a>
            </div>
            <h5>or</h5>
            <div class="border-left pl-3 mb-4 mt-4">
                <h3>Add single student</h3>
                <p>If the student is not in our database, a new entry will be created. Otherwise we'll match existing student using Academic ID and add that student into your section</p>
            </div>
            <?php echo csrf_field(); ?>
            <div class="border-left pl-3">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label for="academicid" class="h5">Academid ID</label>
                            <input type="text" name="academicid" id="academicid" class="form-control" placeholder="Enter student's Academic ID" value="<?php echo e(old('academicid')); ?>">
                            <?php $__errorArgs = ['academicid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label for="firstname" class="h5">First Name</label>
                            <input type="text" name="firstname" id="firstname" class="form-control" placeholder="Enter student's first name" value="<?php echo e(old('firstname')); ?>">
                            <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label for="lastname" class="h5">Last Name</label>
                            <input type="text" name="lastname" id="lastname" class="form-control" placeholder="Enter student's last name" value="<?php echo e(old('lastname')); ?>">
                            <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="border-left pl-3 mt-4">
                <button class="btn btn-seablue" type="submit">Add Student</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.faculty_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\msi\repos\asw\resources\views/faculty/section/addstudent.blade.php ENDPATH**/ ?>