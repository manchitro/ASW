

<?php $__env->startSection('content'); ?>
    <div class="container-fluid main-content py-4 d-flex flex-wrap ">
        <form action="" method="post" class="section-form w-100">
            <?php echo csrf_field(); ?>
            <div class=" pl-3">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label for="oldpassword" class="h5">Old Password</label>
                            <input type="password" class="form-control" name="oldpassword" id="oldpassword" placeholder="Enter your old password">
                            <?php $__errorArgs = ['oldpassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <?php if(session('errorpass')): ?>
                                <div class="text-danger"><?php echo e(session('errorpass')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label for="newpassword" class="h5">New Password</label>
                            <input type="password" class="form-control" name="newpassword" id="newpassword" placeholder="Enter a new password">
                            <?php $__errorArgs = ['newpassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label for="confirmnewpassword" class="h5">Confirm New Password</label>
                            <input type="password" class="form-control" name="confirmnewpassword" id="confirmnewpassword" placeholder="Confirm your new password">
                            <?php $__errorArgs = ['confirmnewpassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class=" pl-3 mt-4">
                <button class="btn btn-seablue" type="submit">Save</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.faculty_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\msi\repos\asw\resources\views/faculty/profile/changepassword.blade.php ENDPATH**/ ?>