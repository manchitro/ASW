

<?php $__env->startSection('content'); ?>
    <div class="container-fluid main-content py-4 d-flex flex-wrap ">
        <form action="/faculty/section/create" method="post" class="section-form w-100">
            <?php echo csrf_field(); ?>
            <div class="border-left pl-3">
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label for="sectionname" class="h3">Section Name</label>
                            <input type="text" name="sectionname" id="sectionname" class="form-control" placeholder="i.e. Programming Language 1 [A]" value="<?php echo e(old('sectionname')); ?>">
                            <?php $__errorArgs = ['sectionname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="border-left pl-3">
                <div class="row mt-4">
                    <div class="col">
                        <h5>Section Time 1</h5>
                    </div>
                </div>
                <div class="row mt-3">
                    <div class="col">
                        Class Type:
                    </div>
                </div>
                <div class="row mt-2">
                    <div class="col">
                        <div class="form-check form-check-inline">
                            <label class="no-wrap form-check-label">
                                <input type="radio" class="form-check-input" name="classtype1" value="lab" <?php echo e(old('classtype1') == 'lab' ? 'checked' : ''); ?>>
                                Lab
                            </label>
                        </div>
                        <div class="form-check form-check-inline">
                            <label class="no-wrap form-check-label">
                                <input type="radio" class="form-check-input" name="classtype1" value="theory" <?php echo e(old('classtype1') == 'theory' ? 'checked' : ''); ?>>
                                Theory
                            </label>
                        </div>
                        <?php $__errorArgs = ['classtype1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="row st1 mt-4">
                    <div class="col">
                        <div class="form-group">
                            <label for="weekday1">Weekday</label>
                            <?php $__errorArgs = ['weekday1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <select id="weekday1" class="form-control" name="weekday1">
                                <option value="0" <?php echo e(old('weekday1') == 0 ? 'selected' : ''); ?>>Sunday</option>
                                <option value="1" <?php echo e(old('weekday1') == 1 ? 'selected' : ''); ?>>Monday</option>
                                <option value="2" <?php echo e(old('weekday1') == 2 ? 'selected' : ''); ?>>Tuesday</option>
                                <option value="3" <?php echo e(old('weekday1') == 3 ? 'selected' : ''); ?>>Wednesday</option>
                                <option value="4" <?php echo e(old('weekday1') == 4 ? 'selected' : ''); ?>>Thursday</option>
                                <option value="5" <?php echo e(old('weekday1') == 5 ? 'selected' : ''); ?>>Friday</option>
                                <option value="6" <?php echo e(old('weekday1') == 6 ? 'selected' : ''); ?>>Saturday</option>
                            </select>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label for="starttime1">Start time</label>
                            <?php $__errorArgs = ['starttime1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <select id="starttime1" class="form-control" name="starttime1" value="<?php echo e(old('starttime1')); ?>">
                                <option value="0" <?php echo e(old('starttime1') == 0 ? 'selected' : ''); ?>>8:00 AM</option>
                                <option value="1" <?php echo e(old('starttime1') == 1 ? 'selected' : ''); ?>>8:30 AM</option>
                                <option value="2" <?php echo e(old('starttime1') == 2 ? 'selected' : ''); ?>>9:00 AM</option>
                                <option value="3" <?php echo e(old('starttime1') == 3 ? 'selected' : ''); ?>>9:30 AM</option>
                                <option value="4" <?php echo e(old('starttime1') == 4 ? 'selected' : ''); ?>>10:00 AM</option>
                                <option value="5" <?php echo e(old('starttime1') == 5 ? 'selected' : ''); ?>>10:30 AM</option>
                                <option value="6" <?php echo e(old('starttime1') == 6 ? 'selected' : ''); ?>>11:00 AM</option>
                                <option value="7" <?php echo e(old('starttime1') == 7 ? 'selected' : ''); ?>>11:30 AM</option>
                                <option value="8" <?php echo e(old('starttime1') == 8 ? 'selected' : ''); ?>>12:00 PM</option>
                                <option value="9" <?php echo e(old('starttime1') == 9 ? 'selected' : ''); ?>>12:30 PM</option>
                                <option value="10" <?php echo e(old('starttime1') == 10 ? 'selected' : ''); ?>>1:00 PM</option>
                                <option value="11" <?php echo e(old('starttime1') == 11 ? 'selected' : ''); ?>>1:30 PM</option>
                                <option value="12" <?php echo e(old('starttime1') == 12 ? 'selected' : ''); ?>>2:00 PM</option>
                                <option value="13" <?php echo e(old('starttime1') == 13 ? 'selected' : ''); ?>>2:30 PM</option>
                                <option value="14" <?php echo e(old('starttime1') == 14 ? 'selected' : ''); ?>>3:00 PM</option>
                                <option value="15" <?php echo e(old('starttime1') == 15 ? 'selected' : ''); ?>>3:30 PM</option>
                                <option value="16" <?php echo e(old('starttime1') == 16 ? 'selected' : ''); ?>>4:00 PM</option>
                                <option value="17" <?php echo e(old('starttime1') == 17 ? 'selected' : ''); ?>>4:30 PM</option>
                                <option value="18" <?php echo e(old('starttime1') == 18 ? 'selected' : ''); ?>>5:00 PM</option>
                                <option value="19" <?php echo e(old('starttime1') == 19 ? 'selected' : ''); ?>>5:30 PM</option>
                                <option value="20" <?php echo e(old('starttime1') == 20 ? 'selected' : ''); ?>>6:00 PM</option>
                                <option value="21" <?php echo e(old('starttime1') == 21 ? 'selected' : ''); ?>>6:30 PM</option>
                                <option value="22" <?php echo e(old('starttime1') == 22 ? 'selected' : ''); ?>>7:00 PM</option>
                                <option value="23" <?php echo e(old('starttime1') == 23 ? 'selected' : ''); ?>>7:30 PM</option>
                                <option value="24" <?php echo e(old('starttime1') == 24 ? 'selected' : ''); ?>>8:00 PM</option>
                            </select>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label class="no-wrap no-wrap" for="endtime1">End time</label>
                            <select id="endtime1" class="form-control" name="endtime1" value="<?php echo e(old('endtime1')); ?>">
                                <option value="0" <?php echo e(old('endtime1') == 0 ? 'selected' : ''); ?>>8:00 AM</option>
                                <option value="1" <?php echo e(old('endtime1') == 1 ? 'selected' : ''); ?>>8:30 AM</option>
                                <option value="2" <?php echo e(old('endtime1') == 2 ? 'selected' : ''); ?>>9:00 AM</option>
                                <option value="3" <?php echo e(old('endtime1') == 3 ? 'selected' : ''); ?>>9:30 AM</option>
                                <option value="4" <?php echo e(old('endtime1') == 4 ? 'selected' : ''); ?>>10:00 AM</option>
                                <option value="5" <?php echo e(old('endtime1') == 5 ? 'selected' : ''); ?>>10:30 AM</option>
                                <option value="6" <?php echo e(old('endtime1') == 6 ? 'selected' : ''); ?>>11:00 AM</option>
                                <option value="7" <?php echo e(old('endtime1') == 7 ? 'selected' : ''); ?>>11:30 AM</option>
                                <option value="8" <?php echo e(old('endtime1') == 8 ? 'selected' : ''); ?>>12:00 PM</option>
                                <option value="9" <?php echo e(old('endtime1') == 9 ? 'selected' : ''); ?>>12:00 PM</option>
                                <option value="10" <?php echo e(old('endtime1') == 10 ? 'selected' : ''); ?>>1:00 PM</option>
                                <option value="11" <?php echo e(old('endtime1') == 11 ? 'selected' : ''); ?>>1:30 PM</option>
                                <option value="12" <?php echo e(old('endtime1') == 12 ? 'selected' : ''); ?>>2:00 PM</option>
                                <option value="13" <?php echo e(old('endtime1') == 13 ? 'selected' : ''); ?>>2:30 PM</option>
                                <option value="14" <?php echo e(old('endtime1') == 14 ? 'selected' : ''); ?>>3:00 PM</option>
                                <option value="15" <?php echo e(old('endtime1') == 15 ? 'selected' : ''); ?>>3:30 PM</option>
                                <option value="16" <?php echo e(old('endtime1') == 16 ? 'selected' : ''); ?>>4:00 PM</option>
                                <option value="17" <?php echo e(old('endtime1') == 17 ? 'selected' : ''); ?>>4:30 PM</option>
                                <option value="18" <?php echo e(old('endtime1') == 18 ? 'selected' : ''); ?>>5:00 PM</option>
                                <option value="19" <?php echo e(old('endtime1') == 19 ? 'selected' : ''); ?>>5:30 PM</option>
                                <option value="20" <?php echo e(old('endtime1') == 20 ? 'selected' : ''); ?>>6:00 PM</option>
                                <option value="21" <?php echo e(old('endtime1') == 21 ? 'selected' : ''); ?>>6:30 PM</option>
                                <option value="22" <?php echo e(old('endtime1') == 22 ? 'selected' : ''); ?>>7:00 PM</option>
                                <option value="23" <?php echo e(old('endtime1') == 23 ? 'selected' : ''); ?>>7:30 PM</option>
                                <option value="24" <?php echo e(old('endtime1') == 24 ? 'selected' : ''); ?>>8:00 PM</option>
                            </select>
                            <?php $__errorArgs = ['endtime1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-8">
                        <div class="form-group">
                            <label class="no-wrap no-wrap" for="room1">Room</label>
                            <input id="room1" class="form-control" type="text" name="room1" placeholder="i.e. 1102/D0203" value="<?php echo e(old('room1')); ?>">
                            <?php $__errorArgs = ['room1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="border-left pl-3">
                <div class="row mt-4">
                    <div class="col">
                        <div class="form-check">
                            <input id="oneclass" class="form-check-input" type="checkbox" name="oneclass" value="true" data-toggle="collapse" data-target="#st2collapse" aria-expanded="true" role="button" <?php echo e(old('oneclass') == 'true' ? 'checked' : ''); ?>>
                            <label for="oneclass" class="form-check-label">Check this if your section has only one lecture per week (Section time 2 will be ignored)</label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="collapse <?php echo e(old('oneclass') == 'true' ? '' : 'show'); ?>" id="st2collapse">
                <div class="border-left pl-3">
                    <div class="row mt-4">
                        <div class="col">
                            <h5>Section Time 2</h5>
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col">
                            Class Type:
                        </div>
                    </div>
                    <div class="row mt-2">
                        <div class="col">
                            <div class="form-check form-check-inline">
                                <label class="no-wrap form-check-label">
                                    <input type="radio" class="form-check-input" name="classtype2" value="lab" <?php echo e(old('classtype2') == 'lab' ? 'checked' : ''); ?>>
                                    Lab
                                </label>
                            </div>
                            <div class="form-check form-check-inline">
                                <label class="no-wrap form-check-label">
                                    <input type="radio" class="form-check-input" name="classtype2" value="theory" <?php echo e(old('classtype2') == 'theory' ? 'checked' : ''); ?>>
                                    Theory
                                </label>
                            </div>
                            <?php $__errorArgs = ['classtype2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row st1 mt-4">
                        <div class="col">
                            <div class="form-group">
                                <label for="weekday2">Weekday</label>
                                <select id="weekday2" class="form-control" name="weekday2">
                                    <option value="0" <?php echo e(old('weekday2') == 0 ? 'selected' : ''); ?>>Sunday</option>
                                    <option value="1" <?php echo e(old('weekday2') == 1 ? 'selected' : ''); ?>>Monday</option>
                                    <option value="2" <?php echo e(old('weekday2') == 2 ? 'selected' : ''); ?>>Tuesday</option>
                                    <option value="3" <?php echo e(old('weekday2') == 3 ? 'selected' : ''); ?>>Wednesday</option>
                                    <option value="4" <?php echo e(old('weekday2') == 4 ? 'selected' : ''); ?>>Thursday</option>
                                    <option value="5" <?php echo e(old('weekday2') == 5 ? 'selected' : ''); ?>>Friday</option>
                                    <option value="6" <?php echo e(old('weekday2') == 6 ? 'selected' : ''); ?>>Saturday</option>
                                </select>
                                <?php $__errorArgs = ['weekday2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <label for="starttime2">Start time</label>
                                <?php $__errorArgs = ['starttime2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <select id="starttime2" class="form-control" name="starttime2" value="<?php echo e(old('starttime2')); ?>">
                                    <option value="0" <?php echo e(old('starttime2') == 0 ? 'selected' : ''); ?>>8:00 AM</option>
                                    <option value="1" <?php echo e(old('starttime2') == 1 ? 'selected' : ''); ?>>8:30 AM</option>
                                    <option value="2" <?php echo e(old('starttime2') == 2 ? 'selected' : ''); ?>>9:00 AM</option>
                                    <option value="3" <?php echo e(old('starttime2') == 3 ? 'selected' : ''); ?>>9:30 AM</option>
                                    <option value="4" <?php echo e(old('starttime2') == 4 ? 'selected' : ''); ?>>10:00 AM</option>
                                    <option value="5" <?php echo e(old('starttime2') == 5 ? 'selected' : ''); ?>>10:30 AM</option>
                                    <option value="6" <?php echo e(old('starttime2') == 6 ? 'selected' : ''); ?>>11:00 AM</option>
                                    <option value="7" <?php echo e(old('starttime2') == 7 ? 'selected' : ''); ?>>11:30 AM</option>
                                    <option value="8" <?php echo e(old('starttime2') == 8 ? 'selected' : ''); ?>>12:00 PM</option>
                                    <option value="9" <?php echo e(old('starttime2') == 9 ? 'selected' : ''); ?>>12:30 PM</option>
                                    <option value="10" <?php echo e(old('starttime2') == 10 ? 'selected' : ''); ?>>1:00 PM</option>
                                    <option value="11" <?php echo e(old('starttime2') == 11 ? 'selected' : ''); ?>>1:30 PM</option>
                                    <option value="12" <?php echo e(old('starttime2') == 12 ? 'selected' : ''); ?>>2:00 PM</option>
                                    <option value="13" <?php echo e(old('starttime2') == 13 ? 'selected' : ''); ?>>2:30 PM</option>
                                    <option value="14" <?php echo e(old('starttime2') == 14 ? 'selected' : ''); ?>>3:00 PM</option>
                                    <option value="15" <?php echo e(old('starttime2') == 15 ? 'selected' : ''); ?>>3:30 PM</option>
                                    <option value="16" <?php echo e(old('starttime2') == 16 ? 'selected' : ''); ?>>4:00 PM</option>
                                    <option value="17" <?php echo e(old('starttime2') == 17 ? 'selected' : ''); ?>>4:30 PM</option>
                                    <option value="18" <?php echo e(old('starttime2') == 18 ? 'selected' : ''); ?>>5:00 PM</option>
                                    <option value="19" <?php echo e(old('starttime2') == 19 ? 'selected' : ''); ?>>5:30 PM</option>
                                    <option value="20" <?php echo e(old('starttime2') == 20 ? 'selected' : ''); ?>>6:00 PM</option>
                                    <option value="21" <?php echo e(old('starttime2') == 21 ? 'selected' : ''); ?>>6:30 PM</option>
                                    <option value="22" <?php echo e(old('starttime2') == 22 ? 'selected' : ''); ?>>7:00 PM</option>
                                    <option value="23" <?php echo e(old('starttime2') == 23 ? 'selected' : ''); ?>>7:30 PM</option>
                                    <option value="24" <?php echo e(old('starttime2') == 24 ? 'selected' : ''); ?>>8:00 PM</option>
                                </select>
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <label class="no-wrap no-wrap" for="endtime2">End time</label>
                                <select id="endtime2" class="form-control" name="endtime2" value="<?php echo e(old('endtime2')); ?>">
                                    <option value="0" <?php echo e(old('endtime2') == 0 ? 'selected' : ''); ?>>8:00 AM</option>
                                    <option value="1" <?php echo e(old('endtime2') == 1 ? 'selected' : ''); ?>>8:30 AM</option>
                                    <option value="2" <?php echo e(old('endtime2') == 2 ? 'selected' : ''); ?>>9:00 AM</option>
                                    <option value="3" <?php echo e(old('endtime2') == 3 ? 'selected' : ''); ?>>9:30 AM</option>
                                    <option value="4" <?php echo e(old('endtime2') == 4 ? 'selected' : ''); ?>>10:00 AM</option>
                                    <option value="5" <?php echo e(old('endtime2') == 5 ? 'selected' : ''); ?>>10:30 AM</option>
                                    <option value="6" <?php echo e(old('endtime2') == 6 ? 'selected' : ''); ?>>11:00 AM</option>
                                    <option value="7" <?php echo e(old('endtime2') == 7 ? 'selected' : ''); ?>>11:30 AM</option>
                                    <option value="8" <?php echo e(old('endtime2') == 8 ? 'selected' : ''); ?>>12:00 PM</option>
                                    <option value="9" <?php echo e(old('endtime2') == 9 ? 'selected' : ''); ?>>12:00 PM</option>
                                    <option value="10" <?php echo e(old('endtime2') == 10 ? 'selected' : ''); ?>>1:00 PM</option>
                                    <option value="11" <?php echo e(old('endtime2') == 11 ? 'selected' : ''); ?>>1:30 PM</option>
                                    <option value="12" <?php echo e(old('endtime2') == 12 ? 'selected' : ''); ?>>2:00 PM</option>
                                    <option value="13" <?php echo e(old('endtime2') == 13 ? 'selected' : ''); ?>>2:30 PM</option>
                                    <option value="14" <?php echo e(old('endtime2') == 14 ? 'selected' : ''); ?>>3:00 PM</option>
                                    <option value="15" <?php echo e(old('endtime2') == 15 ? 'selected' : ''); ?>>3:30 PM</option>
                                    <option value="16" <?php echo e(old('endtime2') == 16 ? 'selected' : ''); ?>>4:00 PM</option>
                                    <option value="17" <?php echo e(old('endtime2') == 17 ? 'selected' : ''); ?>>4:30 PM</option>
                                    <option value="18" <?php echo e(old('endtime2') == 18 ? 'selected' : ''); ?>>5:00 PM</option>
                                    <option value="19" <?php echo e(old('endtime2') == 19 ? 'selected' : ''); ?>>5:30 PM</option>
                                    <option value="20" <?php echo e(old('endtime2') == 20 ? 'selected' : ''); ?>>6:00 PM</option>
                                    <option value="21" <?php echo e(old('endtime2') == 21 ? 'selected' : ''); ?>>6:30 PM</option>
                                    <option value="22" <?php echo e(old('endtime2') == 22 ? 'selected' : ''); ?>>7:00 PM</option>
                                    <option value="23" <?php echo e(old('endtime2') == 23 ? 'selected' : ''); ?>>7:30 PM</option>
                                    <option value="24" <?php echo e(old('endtime2') == 24 ? 'selected' : ''); ?>>8:00 PM</option>
                                </select>
                                <?php $__errorArgs = ['endtime2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-8">
                            <div class="form-group">
                                <label class="no-wrap no-wrap" for="room2">Room</label>
                                <input id="room2" class="form-control" type="text" name="room2" placeholder="i.e. 1102/D0203" value="<?php echo e(old('room2')); ?>">
                                <?php $__errorArgs = ['room2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="border-left pl-3 mt-4">
                <button class="btn btn-seablue" type="submit">Submit</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.faculty_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\msi\repos\asw\resources\views/faculty/section/create.blade.php ENDPATH**/ ?>