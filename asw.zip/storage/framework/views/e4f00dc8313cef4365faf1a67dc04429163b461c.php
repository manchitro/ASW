

<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('components.right-menu'); ?>
        <?php $__env->slot('sectioneid'); ?>
            <?php echo e($section->eid); ?>

        <?php $__env->endSlot(); ?>
        <?php $__env->slot('currentpage'); ?>
            <?php echo e('students'); ?>

        <?php $__env->endSlot(); ?>
        <?php $__env->slot('rightmenustate'); ?>
            <?php echo e($user->rightmenustate); ?>

        <?php $__env->endSlot(); ?>
    <?php if (isset($__componentOriginal07040f813646d8732f1180ba4b40ef47cbdeac00)): ?>
<?php $component = $__componentOriginal07040f813646d8732f1180ba4b40ef47cbdeac00; ?>
<?php unset($__componentOriginal07040f813646d8732f1180ba4b40ef47cbdeac00); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <?php if(session('messages')): ?>
        <!-- Button trigger modal -->
        <button type="button" class="btn btn-seablue" data-toggle="modal" data-target="#exampleModalLong">
            Spreadsheet import report
        </button>

        <!-- Modal -->
        <div class="modal fade" id="exampleModalLong" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle">Spreadsheet import report</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <?php $__currentLoopData = session('messages'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p><?php echo e($message); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
    <?php if(count($students) == 0): ?>
        <div class="mx-3 text-warning h5">There are no students in this section as of now. To add students use the Add student button from the menu below or <a href="add"><u>click here</u></a></div>
    <?php endif; ?>
    <div class="table-responsive fullscreen-flex-item overflow-auto">
        <table class="table table-dark table-striped table-hover table-sm">
            <thead class="thead-dark">
                <tr>
                    <th scope="col" style="width: 5%">#</th>
                    <th scope="col" style="width: 10%">ID</th>
                    <th scope="col" style="width: 30%">Name</th>
                    <?php $__currentLoopData = $lectures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lecture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th scope="col"><?php echo e(substr($lecture->date, 0, -6)." [".$lecture->classtype."] ".$lecture->starttime."-".$lecture->endtime); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($student->id); ?></th>
                        
                        <td><?php echo e($student->academicid); ?></td>
                        <td><?php echo e($student->firstname . ' ' . $student->lastname); ?></td>
                        <?php $__currentLoopData = $lectures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lecture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($attendance->studentid == $student->id && $attendance->lectureid == $lecture->id): ?>
                                    <td>
                                        <label class="check-container">
                                            <input type="checkbox" class="attendance-check" id="<?php echo e($attendance->eid); ?>" <?php echo e($attendance->entry == 1 ? 'checked' : ''); ?> onclick="togglecheck('<?php echo e($attendance->eid); ?>')">
                                            <span class="checkmark"></span>
                                        </label>
                                    </td>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <script>
        function togglecheck(eid) {
            if ($('#' + eid).is(':checked')) {
                console.log('checked ' + eid)
                // window.open('/faculty/async/toggleattendance/' + eid + '/' + '1')
                $.get('/faculty/async/toggleattendance/' + eid + '/' + '1');
            } else {
                console.log('unchecked ' + eid)
                // window.open('/faculty/async/toggleattendance/' + eid + '/' + '0')
                $.get('/faculty/async/toggleattendance/' + eid + '/' + '0');
            }
            // window.open('/faculty/async/toggleattendance/' + eid + $('#' + eid).is(':checked') ? '1' : '0');
            // $.get('/faculty/async/toggleattendance/' + eid, function(data) {
            //     console.log(data);
            // })
        }

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.faculty_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\msi\repos\asw\resources\views/faculty/section/students.blade.php ENDPATH**/ ?>