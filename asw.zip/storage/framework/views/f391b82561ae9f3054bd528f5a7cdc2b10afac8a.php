<div class="login login-main d-inline vw-30">
    <h2 class="mb-4">Login</h2>
    <?php if(session('message')): ?>
        <div class="alert alert-success">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>
    <form method="post" action="/login">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="uid">Email or Academic ID</label>
            <input type="text" class="form-control" id="uid" name="uid" placeholder="Enter your academic ID or Email Address" value="<?php echo e(old('uid')); ?>" required>
        </div>
        <div class="form-group">
            <label for="exampleInputPassword1">Password</label>
            <input type="password" class="form-control" id="exampleInputPassword1" name="password" placeholder="Enter your password" required>
        </div>
        <div class="buttons d-flex flex-row justify-content-between align-items-center">
            <a href="/register" class="btn btn-primary">Create An Account!</a>
            <button type="submit" class="btn btn-outline-success">Login</button>
        </div>
    </form>
</div>
<?php /**PATH C:\Users\msi\repos\asw\resources\views/components/loginform.blade.php ENDPATH**/ ?>