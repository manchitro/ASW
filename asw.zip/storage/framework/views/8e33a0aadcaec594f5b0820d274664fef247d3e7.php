

<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('components.right-menu'); ?>
        <?php $__env->slot('sectioneid'); ?>
            <?php echo e($section->eid); ?>

        <?php $__env->endSlot(); ?>
        <?php $__env->slot('currentpage'); ?>
            <?php echo e('removestudents'); ?>

        <?php $__env->endSlot(); ?>
        <?php $__env->slot('rightmenustate'); ?>
            <?php echo e($user->rightmenustate); ?>

        <?php $__env->endSlot(); ?>
    <?php if (isset($__componentOriginal07040f813646d8732f1180ba4b40ef47cbdeac00)): ?>
<?php $component = $__componentOriginal07040f813646d8732f1180ba4b40ef47cbdeac00; ?>
<?php unset($__componentOriginal07040f813646d8732f1180ba4b40ef47cbdeac00); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <form method="post" action="" class="table-responsive fullscreen-flex-item overflow-auto">
        <?php echo csrf_field(); ?>
        <div>
            <div class="select-buttons px-4 py-2">
                <button type="submit" class="btn btn-outline-danger">Remove Selected</button>
                <a href="/faculty/section/<?php echo e($section->eid); ?>/students" class="btn btn-outline-seablue">
                    Back
                </a>
            </div>
            <table class="table table-dark table-striped table-hover table-sm">
                <thead class="thead-dark">
                    <tr>
                        <td scope="col" style="width: 5%">
                            <label class="check-container">
                                <input type="checkbox" class="student-check-master" id="select-all">
                                <span class=" checkmark"></span>
                            </label>
                            </th>
                        <th scope="col" style="width: 5%">#</th>
                        <th scope="col" style="width: 10%">ID</th>
                        <th scope="col">Name</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <label class="check-container">
                                    <input type="checkbox" class="student-check" name="student[]" value="<?php echo e($student->eid); ?>">
                                    <span class="checkmark"></span>
                                </label>
                            </td>
                            <th scope="row"><?php echo e($student->id); ?></th>
                            
                            <td><?php echo e($student->academicid); ?></td>
                            <td><?php echo e($student->firstname . ' ' . $student->lastname); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <?php if(count($students) == 0): ?>
            <div class="mx-3 text-warning h5">There are no students in this section as of now. To add students use the Add student button from the menu below or <a href="add"><u>click here</u></a></div>
        <?php endif; ?>
        <script>
            window.addEventListener("load", function() {
                $("#select-all").click(function() {
                    $(".student-check").prop('checked', $(this).prop('checked'));
                });
            });

        </script>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.faculty_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\msi\repos\asw\resources\views/faculty/section/removestudents.blade.php ENDPATH**/ ?>