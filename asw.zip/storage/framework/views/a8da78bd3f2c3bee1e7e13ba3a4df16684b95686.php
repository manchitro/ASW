

<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('components.right-menu'); ?>
        <?php $__env->slot('sectioneid'); ?>
            <?php echo e($section->eid); ?>

        <?php $__env->endSlot(); ?>
    <?php if (isset($__componentOriginal07040f813646d8732f1180ba4b40ef47cbdeac00)): ?>
<?php $component = $__componentOriginal07040f813646d8732f1180ba4b40ef47cbdeac00; ?>
<?php unset($__componentOriginal07040f813646d8732f1180ba4b40ef47cbdeac00); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <div class="container-fluid main-content py-4 d-flex flex-wrap ">
        <?php if(count($lectures) == 0): ?>
            <div class="text-info h5">You have no lectures scheduled as of now for this section. Please create one using the Add Lecture option from the <i class="fas fa-bars"></i> menu button below or from <u><a href="/faculty/section/<?php echo e($section->eid); ?>/lectures/add">here.</a></u> </div>
        <?php endif; ?>
        <?php $__currentLoopData = $lectures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lecture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card nightbg soft-shadow mx-5 my-3">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($section->sectionname); ?></h5>
                    
                    <?php $__currentLoopData = $section->sectiontimes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sectiontime): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <h6 class="card-text font-italic text-nowrap"><?php echo e('[' . $sectiontime->classtype . '] ' . $sectiontime->weekday . ' ' . $sectiontime->starttime . ' - ' . $sectiontime->endtime . ' at ' . $sectiontime->room); ?></h6>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if(count($section->sectiontimes) == 1): ?>
                        <h6 class="card-text font-italic text-nowrap"><br></h6>
                    <?php endif; ?>
                    <div class="d-flex flex-row justify-content-between align-items-center mt-3">
                        <a href="/faculty/section/<?php echo e($section->eid); ?>/students/" class=""><button class="btn btn-outline-seablue">Students</button></a>
                        <a href="/faculty/section/<?php echo e($section->eid); ?>/classes" class=""><button class="btn btn-outline-seablue">Lectures</button></a>
                        <a href="/faculty/section/<?php echo e($section->eid); ?>/edit" class=""><button class="btn btn-outline-seablue">Edit</button></a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.faculty_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\msi\repos\asw\resources\views/faculty/section/lectures.blade.php ENDPATH**/ ?>