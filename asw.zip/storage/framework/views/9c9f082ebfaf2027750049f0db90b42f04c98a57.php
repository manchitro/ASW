

<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('components.right-menu'); ?>
        <?php $__env->slot('sectioneid'); ?>
            <?php echo e($section->eid); ?>

        <?php $__env->endSlot(); ?>
        <?php $__env->slot('currentpage'); ?>
            <?php echo e('lectures'); ?>

        <?php $__env->endSlot(); ?>
        <?php $__env->slot('rightmenustate'); ?>
            <?php echo e($user->rightmenustate); ?>

        <?php $__env->endSlot(); ?>
    <?php if (isset($__componentOriginal07040f813646d8732f1180ba4b40ef47cbdeac00)): ?>
<?php $component = $__componentOriginal07040f813646d8732f1180ba4b40ef47cbdeac00; ?>
<?php unset($__componentOriginal07040f813646d8732f1180ba4b40ef47cbdeac00); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <div class="container-fluid main-content py-4 d-flex flex-wrap ">
        <?php if(count($lectures) == 0): ?>
            <div class="text-info h5">You have no lectures scheduled as of now for this section. Please create one using the Add Lecture option from the <i class="fas fa-bars"></i> menu button below or from <u><a href="/faculty/section/<?php echo e($section->eid); ?>/lectures/add">here.</a></u> </div>
        <?php endif; ?>
        <?php $__currentLoopData = $lectures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lecture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card nightbg soft-shadow mx-3 my-3">
                <div class="card-body">
                    <h6 class="card-title"><?php echo e($section->sectionname); ?></h6>
                    <h4 class="card-title"><?php echo e($lecture->classtype); ?></h4>
                    <h6 class="card-text"><?php echo e('on ' . $lecture->date); ?></h6>
                    <h6 class="card-text font-italic text-nowrap mt-2"><?php echo e('from ' . $lecture->starttime . ' to ' . $lecture->endtime . ' at ' . $lecture->room); ?></h6>
                    <div class="d-flex flex-row justify-content-between align-items-center mt-3">
                        
                        <a href="/faculty/section/<?php echo e($section->eid); ?>/lectures/<?php echo e($lecture->eid); ?>/edit" class="" <?php if(strtotime($lecture->date) < strtotime('today')): ?> echo <?php echo e(Popper::trigger(true, true, true)->position('bottom')->arrow()->danger('Cannot edit past classes. You can delete this class and create a new one.')); ?> <?php endif; ?>><button class="btn btn-outline-seablue mx-4" <?php if(strtotime($lecture->date) < strtotime('today')): ?> echo disabled <?php endif; ?>>Edit</button></a>
                        <a href="/faculty/section/<?php echo e($section->eid); ?>/lectures/<?php echo e($lecture->eid); ?>/delete" class="" onclick="return confirm('Are you sure you want to delete this lecture? All attendance data of this lecture will be permanently deleted!')"><button class="btn btn-outline-danger">Delete</button></a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.faculty_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\msi\repos\asw\resources\views/faculty/section/lecture/lectures.blade.php ENDPATH**/ ?>