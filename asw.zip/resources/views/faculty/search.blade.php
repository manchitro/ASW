@extends('layouts.faculty_layout')

@section('content')
@endsection
